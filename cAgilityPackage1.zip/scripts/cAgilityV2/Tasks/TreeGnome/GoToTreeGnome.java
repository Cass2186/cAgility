package scripts.cAgilityV2.Tasks.TreeGnome;

import org.tribot.api2007.Player;
import scripts.Utility.PathingUtil;
import scripts.cAgilityV2.API.Priority;
import scripts.cAgilityV2.API.Task;
import scripts.cAgilityV2.AgilityAPI.AgilUtils;
import scripts.cAgilityV2.AgilityAPI.COURSES;
import scripts.cAgilityV2.Data.AgilityAreas;

public class GoToTreeGnome implements Task {


    @Override
    public String toString(){
        return "Going to Tree gnome course";
    }

    @Override
    public Priority priority() {
        return Priority.HIGH;
    }

    @Override
    public boolean validate() {
        // will need another check for this course
        return AgilUtils.isWithinLevelRange(0, 10) &&
                Player.getPosition().getPlane() == 0 &&
                !AgilityAreas.WHOLE_TG_COURSE_LEVEL_0.contains(Player.getPosition()) &&
                !AgilityAreas.WHOLE_TG_COURSE_LEVEL_2.contains(Player.getPosition()) &&
                !AgilityAreas.WHOLE_TG_COURSE_LEVEL_1.contains(Player.getPosition());
    }

    @Override
    public void execute() {
        PathingUtil.walkToArea(AgilityAreas.TG_START_AREA, false);
    }

    @Override
    public String course() {
        return COURSES.TREE_GNOME_STRONGHOLD.courseName;
    }
}
