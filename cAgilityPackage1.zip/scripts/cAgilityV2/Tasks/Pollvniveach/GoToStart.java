package scripts.cAgilityV2.Tasks.Pollvniveach;


import org.tribot.api.General;
import org.tribot.api2007.Player;
import scripts.Fremmy.api.Utilities;
import scripts.Utility.PathingUtil;
import scripts.cAgilityV2.API.Priority;
import scripts.cAgilityV2.API.Task;
import scripts.cAgilityV2.AgilityAPI.AgilUtils;
import scripts.cAgilityV2.AgilityAPI.COURSES;
import scripts.cAgilityV2.Data.AgilityAreas;

public class GoToStart implements Task {

    int chanceOfClickingStartTile = General.random(40, 68);


    @Override
    public String toString() {
        return "Going to Polv start";
    }


    @Override
    public Priority priority() {
        return Priority.HIGHEST;
    }

    @Override
    public boolean validate() {
        return AgilUtils.isWithinLevelRange(70, 80) &&
                Player.getPosition().getPlane() == 0 &&
                !AgilityAreas.POLV_LARGE_START_AREA.contains(Player.getPosition());
    }


    @Override
    public void execute() {
        General.println("[Debug]: Going to Polv start");
        PathingUtil.walkToArea(AgilityAreas.POLV_START_AREA, false);
        int c = General.random(0, 100);
        if (c > chanceOfClickingStartTile) {
            General.println("[Debug]: Screen walking to start");
            Utilities.clickScreenWalk(AgilityAreas.POLV_START_TILE);
        }

    }

    @Override
    public String course() {
        return COURSES.POLLNIVEACH.courseName;
    }
}
