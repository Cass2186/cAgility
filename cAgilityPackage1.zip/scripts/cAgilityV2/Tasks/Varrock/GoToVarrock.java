package scripts.cAgilityV2.Tasks.Varrock;

import org.tribot.api.General;
import org.tribot.api2007.Player;
import org.tribot.api2007.Walking;
import scripts.Utility.PathingUtil;
import scripts.Utility.Timer;
import scripts.cAgilityV2.API.Priority;
import scripts.cAgilityV2.API.Task;
import scripts.cAgilityV2.AgilityAPI.AgilUtils;
import scripts.cAgilityV2.AgilityAPI.COURSES;
import scripts.cAgilityV2.Data.AgilityAreas;

public class GoToVarrock implements Task {




    @Override
    public String toString(){
        return "Going to Varrock course";
    }


    @Override
    public Priority priority() {
        return Priority.HIGH;
    }

    @Override
    public boolean validate() {
        return AgilUtils.isWithinLevelRange(20, 30) &&
                Player.getPosition().getPlane() ==0 &&
                !AgilityAreas.VARROCK_GROUND_START_AREA.contains(Player.getPosition()) &&
                !AgilityAreas.VARROCK_LEVEL_1.contains(Player.getPosition()) &&
                !AgilityAreas.VARROCK_LEVEL_3.contains(Player.getPosition());

    }

    @Override
    public void execute() {
        if (AgilityAreas.VARROCK_END_GROUND_AREA.contains(Player.getPosition())){
            General.println("[Debug]; Walking path to start");
            Walking.walkPath(AgilityAreas.VARROCK_PATH_TO_START);
            Timer.waitCondition(()-> AgilityAreas.VARROCK_PATH_TO_START[1]
                    .distanceTo(Player.getPosition()) <General.random(2,5), 6000,9000);
        }
        PathingUtil.walkToArea(AgilityAreas.VARROCK_GROUND_START_AREA, false);
    }

    @Override
    public String course() {
        return COURSES.VARROCK.courseName;
    }
}
