package scripts.cAgilityV2.Tasks.DraynorVillage;

import org.tribot.api2007.Player;
import scripts.Utility.PathingUtil;
import scripts.cAgilityV2.API.Priority;
import scripts.cAgilityV2.API.Task;
import scripts.cAgilityV2.AgilityAPI.AgilUtils;
import scripts.cAgilityV2.AgilityAPI.COURSES;
import scripts.cAgilityV2.Data.AgilityAreas;

public class GoToDraynor implements Task {

    @Override
    public String toString(){
        return "Going to Draynor course";
    }


    @Override
    public Priority priority() {
        return Priority.HIGH;
    }

    @Override
    public boolean validate() {
        return AgilUtils.isWithinLevelRange(10, 30) &&
                Player.getPosition().getPlane() == 0
                && !AgilityAreas.DRAYNOR_LARGE_START_AREA.contains(Player.getPosition());
    }

    @Override
    public void execute() {
        PathingUtil.walkToArea(AgilityAreas.DRAYNOR_START_AREA, false);
    }

    @Override
    public String course() {
        return COURSES.DRAYNOR_VILLAGE.courseName;
    }
}
