package scripts.cAgilityV2.Data;

import org.tribot.api.General;
import org.tribot.api2007.Skills;
import scripts.cAgilityV2.cAgility;

public class ExperienceListener implements Runnable {

    public int STARTING_XP = Skills.getXP(Skills.SKILLS.AGILITY);
    public int currentXp;
    public static int count = 0;

    @Override
    public void run() {
        while (cAgility.isRunning) {
            General.sleep(50);
            currentXp = Skills.getXP(Skills.SKILLS.AGILITY);
            if (currentXp > STARTING_XP) {
                STARTING_XP = currentXp;
                count++;
            } else
                General.sleep(50);
        }
    }
}
