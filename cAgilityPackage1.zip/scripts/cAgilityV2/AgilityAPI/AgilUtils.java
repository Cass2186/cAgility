package scripts.cAgilityV2.AgilityAPI;

import org.tribot.api.General;
import org.tribot.api2007.GroundItems;
import org.tribot.api2007.Player;
import org.tribot.api2007.Skills;
import org.tribot.api2007.types.RSArea;
import org.tribot.api2007.types.RSGroundItem;
import scripts.Fremmy.api.Utilities;
import scripts.cAgilityV2.Data.Const;
import scripts.cAgilityV2.Data.Vars;
import scripts.dax_api.walker.utils.camera.DaxCamera;

import java.awt.*;
import java.util.List;
import java.util.Optional;

public class AgilUtils {


    public static Optional<Obstacle> getCurrentObstacle(List<Obstacle> allObstacles) {
        for (int i = 0; i < allObstacles.size(); i++) {
            if (allObstacles.get(i).isValidObstacle()) {

                return Optional.ofNullable(allObstacles.get(i));
            }
        }
        return Optional.empty();
    }


    public static boolean isWithinLevelRange(int lower, int upper) {
        return Skills.getCurrentLevel(Skills.SKILLS.AGILITY) < upper &&
                Skills.getCurrentLevel(Skills.SKILLS.AGILITY) >= lower;
    }

    public static void getMark(RSArea area) {
        RSGroundItem[] mark = GroundItems.findNearest(Const.MARK_OF_GRACE_ID);
        if (mark.length > 0 && area.contains(mark[0].getPosition()) && area.contains(Player.getPosition())) {

            if (!mark[0].isClickable())
                DaxCamera.focus(mark[0]);

            General.println("[Debug]: Getting Mark of Grace", Color.RED);
            if(Utilities.clickGroundItem(Const.MARK_OF_GRACE_ID))
                Vars.get().marksCollected++;
        }
    }



}
