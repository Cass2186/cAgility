package scripts.cAgilityV2.API;

public interface Task {

    Priority priority();

    boolean validate();

    void execute();

    String course();

}